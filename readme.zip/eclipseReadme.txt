1) Open Eclipse
2) File -> Import... -> General -> Existing Projects into Workspace
3) Select archive file: jadeCW_inital.zip
4) Run -> Run Configurations 
5) double click Java Application on the left, select JadeCW application, then set Main class to: jade.Boot
6) on the Arguments tab, enter "-gui testAgent:jadeCW.HelloWorldAgent" for Program Arguments
7) Apply and Run
8) "Hello World! My name is testAgent" should be displayed on the console