
jadeLoc=$HOME/MARA/jade-3.7/jade

javac -classpath "$jadeLoc/lib/jade.jar:$jadeLoc/lib/jadeTools.jar:$jadeLoc/lib/http.jar:$jadeLoc:." $@